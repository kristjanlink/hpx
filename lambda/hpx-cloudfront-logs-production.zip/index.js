'use strict'

const url = require('url')
const AWS = require('aws-sdk')
const firehose = new AWS.Firehose()
const s3 = new AWS.S3()
const zlib = require('zlib')
const util = require('util')
const gunzip = util.promisify(zlib.gunzip)
const querystring = require('querystring');

exports.handler = async function(event, context, callback) {
  const promises = []
  const firehose_records = []
  console.info('Reading S3 file')
  for (const record of event.Records) {
    const response = await s3.getObject( { Bucket: record.s3.bucket.name, Key: record.s3.object.key }).promise()
    const data = (await gunzip(response.Body)).toString()
    for(const line of data.trim().split("\n")) {
      const fh_record = []
      if(line.startsWith("#")) {
        continue
      }
      const fields = line.split("\t")
      fh_record.push(fields[0] + " " + fields[1])
      fh_record.push(fields[4])
      fh_record.push(fields[10])
      fh_record.push(fields[7] + "?" + fields[11])
      const query = querystring.parse(fields[11])
      fh_record.push(query.a || '')
      fh_record.push(query.b || '')
      fh_record.push(query.c || '')
      fh_record.push(query.d || '')

      firehose_records.push({Data: fh_record.join("\t") + "\n"})

      // Batch will only take 500 records
      if(firehose_records.length == 500) {
        promises.push(firehose.putRecordBatch({
          DeliveryStreamName: 'hpx-kinesis',
          Records: firehose_records
        }).promise())
        firehose_records = []
      }
    }

    // flush any remaining
    promises.push(firehose.putRecordBatch({
      DeliveryStreamName: 'hpx-kinesis',
      Records: firehose_records
    }).promise())
  }
  // TODO: what to do with failed responses
  const responses = await Promise.all(promises)
  const retval = responses.reduce((acc, response) =>
    acc.concat(response.RequestResponses), [])

  callback(null, retval)
}
