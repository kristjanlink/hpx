// https://eslint.org/docs/user-guide/configuring

module.exports = {
  root: true,
  parserOptions: {
    ecmaVersion: 2017
  },
  rules: {
    'no-restricted-syntax': 0,
    'semi' : ['error', 'never'],
    'camelcase' : 0,
    'no-underscore-dangle': 0,
  }
}
